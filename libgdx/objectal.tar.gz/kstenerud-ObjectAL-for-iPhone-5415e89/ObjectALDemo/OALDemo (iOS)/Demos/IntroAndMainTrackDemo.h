//
//  IntroAndMainTrackDemo.h
//  ObjectAL
//
//  Created by Karl Stenerud on 12-09-06.
//

#import "CCLayer.h"

/**
 * Demonstrates three ways to play an intro followed by the main part of a song.
 */
@interface IntroAndMainTrackDemo : CCLayerColor

@end
