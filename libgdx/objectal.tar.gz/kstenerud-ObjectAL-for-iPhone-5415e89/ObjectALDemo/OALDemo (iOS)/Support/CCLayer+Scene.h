//
//  CCLayer+Scene.h
//  ObjectAL
//
//  Created by Karl Stenerud on 10-08-17.
//

#import "cocos2d.h"


@interface CCLayer (Scene)

+(id) scene;

@end
