ObjectAL Demos
==============

Various demos showing off ObjectAL's functionality.

There is an iOS target and an OSX target.


Cocoapods
---------

You need **Cocoapods** to build the demo project.

General getting started instructions are available at http://cocoapods.org but in a nutshell:

### Installing Cocoapods:

    $ [sudo] gem install cocoapods
    $ pod setup

### Setting up the ObjectALDemo project (from within the ObjectALDemo dir):

    $ pod install

Once the pod is installed, open **ObjectALDemo.xcworkspace**.
