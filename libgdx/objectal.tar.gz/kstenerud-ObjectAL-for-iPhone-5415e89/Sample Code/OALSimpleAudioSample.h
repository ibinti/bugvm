//
//  OALSimpleAudioSample.h
//  ObjectAL
//
//  Created by Karl Stenerud on 10-10-09.
//

#import <Foundation/Foundation.h>


/**
 * This is a copy of the sample code presented in the ObjectAL documentation.
 */
@interface OALSimpleAudioSample : NSObject
{
	// No objects to keep track of...
}

@end
